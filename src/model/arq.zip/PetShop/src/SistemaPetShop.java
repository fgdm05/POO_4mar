
public class SistemaPetShop {

	private Veterinario veterinarios[] = new Veterinario[50];
	private int quantidadeVeterinarios = 0;
	
	public void cadastrarVeterinario(String nome, double salario) {
		Veterinario vet = new Veterinario();
		vet.setNome(nome);
		vet.setSalario(salario);
		veterinarios[quantidadeVeterinarios] = vet;
		quantidadeVeterinarios++;
	}
	public void mostrarVeterinarios() {
		for(int i = 0; i < quantidadeVeterinarios; i++) {
			Veterinario v = veterinarios[i];
			String msg = String.format("Nome: %s, Salário: %lf", v.getNome(), v.getSalario());
			System.out.println();
		}
	}
	public void cadastrarEnderecoDoVeterinario() {
		
	}
	public void cadastrarAnimal() {
		
	}
	public void mostrarAnimais() {
		
	}
	public void cadastrarDono() {
		
	}
	public void cadastrarEnderecoDoDono() {
		
	}
	
}
