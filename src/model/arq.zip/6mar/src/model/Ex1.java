package model;

import java.util.Scanner;

public class Ex1 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int[] valores = new int[5];
		float media = 0;
		for(int i = 0; i < 5; i++) {
			valores[i] = s.nextInt();
			media += valores[i];
		}
		s.close();
		System.out.println("Media = " + media / 5);
		
	}
}
