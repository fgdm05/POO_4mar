package model;

import java.util.Scanner;

public class Ex2 {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		
		int[] idades = new int[5];
		String[] nomes = new String[5];
		
		for(int i = 0; i < 5; i++) {
			System.out.println("Digite a idade (" + (i+1) + "): ");
			idades[i] = Integer.parseInt(s.nextLine());
			System.out.println("Digite o nome (" + (i+1) + "): ");
			nomes[i] = s.nextLine();
		}
		s.close();
		
		for(int i = 0; i < 4; i++) {
			for(int j = 1; j < 5; j++) {
				if(idades[i] > idades[j]) {
					int aux = idades[i];
					idades[i] = idades[j];
					idades[j] = aux;
					
					String auxS = nomes[i];
					nomes[i] = nomes[j];
					nomes[j] = auxS;
					
				}
			}
			
			
		}
		
		for(int i = 0; i < 5; i++) {
			
			System.out.println("Nome " + i + " : " + nomes[i]);
			System.out.println("Idade " + i + " : " + idades[i]);
		}
	}
}
