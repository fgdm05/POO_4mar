
public class Grupo {
	private Pessoa[] pessoas = new Pessoa[5];
	private int numeroPessoas = 0;
	
	public Pessoa[] getPessoas() {
		return pessoas;
	}
	
	public void setPessoa(Pessoa p) {
		if(numeroPessoas < 5) {
			pessoas[numeroPessoas] = p;
			numeroPessoas++;
		}
	}
	
	public void ordena() {
		for(int i = 0; i < 5; i++) {
			for(int j = i + 1; j < 5; j++) {
				if(pessoas[j].calcularIMC() > pessoas[i].calcularIMC()) {
					Pessoa aux = pessoas[j];
					pessoas[j] = pessoas[i];
					pessoas[i] = aux;
				}
			}
		}
	}
	
	
}